#include "ServerBackupLog.hpp"

int main()
{
    Server server;
    server.start();

    return 0;
}